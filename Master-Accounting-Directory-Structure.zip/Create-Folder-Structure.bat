@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Create-Folder-Structure.ps1"
