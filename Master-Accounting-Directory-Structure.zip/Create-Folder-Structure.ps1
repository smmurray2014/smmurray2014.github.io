# Master Accounting Directory Structure - Builder Script
# Created and designed by S. Michelle Murray
#
# Run this from inside the location where you want "2026_FINANCIAL_RECORDS"
# to be created (e.g. double-click Create-Folder-Structure.bat, which
# launches this script from its own folder).

$root = "2026_FINANCIAL_RECORDS"

$structure = @{
    "2026_03_March_Close\00_Financial_Statements" = @(
        "Balance_Sheet_Final_Mar2026.pdf",
        "Income_Statement_Final_Mar2026.pdf",
        "Trial_Balance_Adjusted.pdf"
    )
    "2026_03_March_Close\01_Bank_&_Cash_Reconciliations" = @(
        "Operating_Bank_Reconciliation.xlsx",
        "Operating_Bank_Statement.pdf",
        "Corporate_Credit_Card_Rec.xlsx"
    )
    "2026_03_March_Close\02_Revenue_&_WIP_Schedules" = @(
        "Master_WIP_Workbook.xlsx"
    )
    "2026_03_March_Close\02_Revenue_&_WIP_Schedules\Monthly_Billing_Records" = @()
    "2026_03_March_Close\03_Accounts_Payable_&_Accruals" = @(
        "AP_Aging_Subledger_TieOut.xlsx",
        "Unvouchered_Liabilities_Accrual_Log.xlsx"
    )
    "2026_03_March_Close\04_Payroll_&_Tax_Compliance" = @(
        "Monthly_Payroll_Register_Summary.pdf",
        "MultiState_SalesUseTax_Worksheet.xlsx",
        "WA_L&I_Premium_Tracking_Log.xlsx"
    )
    "2026_03_March_Close\05_Fixed_Assets_&_Equipment" = @(
        "Monthly_Depreciation_Schedule.xlsx",
        "Equipment_Utilization_CostRecovery.xlsx"
    )
    "2026_03_March_Close\06_Journal_Entries_&_Cleanup_Notes" = @(
        "Manual_AJE_Log_&_Calculations.xlsx",
        "AP_Clearing_RootCause_Memo.md"
    )
    "Template_Blank_Close_Structure" = @()
}

Write-Host "Building folder structure under '$root'..." -ForegroundColor Cyan

foreach ($folder in $structure.Keys) {
    $fullPath = Join-Path $root $folder
    New-Item -ItemType Directory -Path $fullPath -Force | Out-Null
    Write-Host "Created folder: $fullPath"

    foreach ($file in $structure[$folder]) {
        $filePath = Join-Path $fullPath $file
        if (-not (Test-Path $filePath)) {
            New-Item -ItemType File -Path $filePath -Force | Out-Null
            Write-Host "  Created placeholder file: $file"
        }
    }
}

Write-Host ""
Write-Host "Done! Your folder structure is ready under '$root'." -ForegroundColor Green
Write-Host "To set up a new month, copy 'Template_Blank_Close_Structure', rename it (e.g. 2026_04_April_Close), and build out its subfolders the same way."
Write-Host ""
Read-Host "Press Enter to close this window"
