HOW TO BUILD YOUR CLOSE FOLDER STRUCTURE
==========================================

This builds the entire "2026_FINANCIAL_RECORDS" folder tree automatically —
every subfolder and every placeholder file — in one click. No manual
folder-creation needed.

WHAT YOU NEED
-------------
This comes as one zip file containing four items:
  - Master-Accounting-Directory-Structure.pdf   (the reference diagram)
  - Create-Folder-Structure.bat                  (the one you'll double-click)
  - Create-Folder-Structure.ps1                  (the actual script — required, don't delete)
  - This README

The .bat and .ps1 files must stay together in the same folder for the
script to work — unzipping keeps them together automatically.

STEP-BY-STEP, STARTING FROM SCRATCH
-------------------------------------
1. Download the zip file. It will land in your computer's "Downloads"
   folder automatically — that's the default save location for
   pretty much anything you download, so you don't need to choose
   where it goes.

2. Open File Explorer (the folder icon in your taskbar), click
   "Downloads" on the left, and find the zip file — it'll look like a
   folder with a zipper icon on it.

3. Right-click the zip file and choose "Extract All..." Windows will
   ask where to put the extracted files — the default option (a new
   folder right there in Downloads) is fine. Click "Extract."

4. Open that newly extracted folder. You'll now see all four files
   sitting together, including both Create-Folder-Structure.bat and
   Create-Folder-Structure.ps1.

5. Double-click "Create-Folder-Structure.bat" — just like opening any
   program. A black window will briefly pop up and show each folder and
   file being created.

6. When it says "Done!", press Enter to close that window.

7. Look inside that same extracted folder. You'll now see a brand-new
   folder called "2026_FINANCIAL_RECORDS" sitting there, already fully
   built out with every subfolder and placeholder file inside it.

WHAT TO DO AFTER IT'S BUILT
-----------------------------
The new "2026_FINANCIAL_RECORDS" folder was created inside Downloads,
which usually isn't where you want to keep it long-term. Simply drag
that whole folder out of Downloads and drop it wherever you actually
want to work from — for example:
  - Your Documents folder
  - Your Desktop
  - A dedicated "Accounting" folder you already use
  - A shared drive or cloud-synced folder (OneDrive, Google Drive, etc.)

Once it's moved, start replacing the empty placeholder files inside each
subfolder with your real monthly workpapers.

SETTING UP A NEW MONTH
-----------------------
The script also creates an empty "Template_Blank_Close_Structure" folder.
To start April, May, etc.:
  1. Copy the "00_" through "06_" subfolders from March into a new folder
  2. Rename that new folder (e.g. "2026_04_April_Close")
  3. Clear out the placeholder files inside and drop in that month's
     real workpapers

TROUBLESHOOTING
----------------
When you double-click "Create-Folder-Structure.bat," Windows will likely
show a window titled "Open File - Security Warning," saying "The
publisher could not be verified. Are you sure you want to run this
software?" with a "Publisher: Unknown Publisher" line.

This is completely normal and expected for any script downloaded from
the internet that isn't digitally signed by a company (which costs
money and most personal scripts don't have). It does NOT mean anything
is wrong or unsafe — it's just Windows being cautious by default.

Click "Run" to proceed. The script will then do its job as described
above.

If you ever see a message about "execution policy" — that's normal and
already handled inside the .bat file; you shouldn't need to change any
Windows settings yourself.

---
Created and designed by S. Michelle Murray
