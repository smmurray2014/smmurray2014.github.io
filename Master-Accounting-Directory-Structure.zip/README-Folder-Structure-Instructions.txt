HOW TO BUILD YOUR CLOSE FOLDER STRUCTURE
==========================================

This builds a complete set of accounting folders for you automatically —
every subfolder, already in place — so you don't have to create them
by hand, one at a time.

WHAT'S IN THIS DOWNLOAD
-------------------------
You downloaded ONE zip file. Inside that zip are FOUR separate items:

  1. Master-Accounting-Directory-Structure.pdf
     A picture/diagram of what the finished folder structure looks like.

  2. Create-Folder-Structure.bat
     This is the file you will double-click to make everything happen.

  3. Create-Folder-Structure.ps1
     This is the actual instructions the .bat file follows. You never
     open or click this one directly — just don't delete it, and keep
     it in the same folder as the .bat file.

  4. This README file.

PART 1: UNZIPPING THE DOWNLOAD
---------------------------------
1. Look in your computer's "Downloads" folder. Anything you download
   from a web browser lands there automatically, so that's where to
   look first.

2. Find the zip file. It will have a small zipper icon on it.

3. Right-click on that zip file. A menu will pop up.

4. Click "Extract All..." on that menu.

5. A small window will appear asking where to put the files. You can
   leave this as-is. Click the "Extract" button.

6. A new folder will appear in your Downloads folder, with the same
   name as the zip file. Open it by double-clicking it.

7. You should now see all four items listed above sitting inside,
   as separate files you can click on individually.

PART 2: BUILDING THE FOLDERS
--------------------------------
1. Inside that same folder, find "Create-Folder-Structure.bat."

2. Double-click it.

3. Windows will likely show a warning window. This is normal — see
   the TROUBLESHOOTING section below for exactly what it says and
   what to do.

4. After that, a black window will pop open by itself. Text will
   scroll by quickly, listing folder names as they're created. This
   is normal and only takes a few seconds.

5. When the black window says "Done!" near the bottom, press the
   Enter key on your keyboard. The black window will close.

6. Look inside the same folder again. You will now see a brand-new
   folder called "2026_FINANCIAL_RECORDS" that was not there before.
   Open it — inside, you'll find everything already built out:
   folders for financial statements, bank reconciliations, payroll,
   and so on, exactly matching the picture in the PDF.

PART 3: MOVING IT SOMEWHERE PERMANENT
-----------------------------------------
Right now, "2026_FINANCIAL_RECORDS" is sitting inside your Downloads
folder, which isn't a good permanent home for it (Downloads folders
tend to get cluttered and cleaned out over time).

1. Click once on the "2026_FINANCIAL_RECORDS" folder to select it
   (don't double-click — just one click, so it gets a blue highlight).

2. Cut it by pressing Ctrl and X on your keyboard at the same time.

3. Go to wherever you actually want to keep this long-term — for
   example, open your Documents folder, or your Desktop, or a
   OneDrive/Google Drive folder you already use.

4. Paste it there by pressing Ctrl and V at the same time.

5. The folder is now moved. You can delete the leftover zip file and
   the extracted folder from your Downloads folder if you like —
   they're no longer needed.

PART 4: STARTING A NEW MONTH (April, May, and beyond)
----------------------------------------------------------
Inside "2026_FINANCIAL_RECORDS," alongside the March folder, you'll
find one more folder called:

    Year_XX_Month_Close_Template

This folder is intentionally empty of any files, but it already has
all seven subfolders inside it (00_Financial_Statements,
01_Bank_&_Cash_Reconciliations, and so on) — the same subfolders as
March, just with nothing filed in them yet.

Its name is written as a fill-in-the-blank pattern, so you know exactly
what to type when you rename your copy. Here's a worked example for
April:

  Step 1 — Click once on "Year_XX_Month_Close_Template" to select it.

  Step 2 — Press Ctrl and C to copy it.

  Step 3 — Click on empty space just below it (still inside
  "2026_FINANCIAL_RECORDS") and press Ctrl and V to paste. A duplicate
  folder will appear, probably named something like
  "Year_XX_Month_Close_Template - Copy."

  Step 4 — Right-click that new duplicate folder and choose "Rename."

  Step 5 — Type a new name, replacing each placeholder word with the
  real value for the month you're starting:
      Year   becomes  2026
      XX     becomes  04     (April is month 4, always written with
                               two digits — January would be 01)
      Month  becomes  April
  So you would type exactly:  2026_04_April_Close

  Step 6 — Press Enter to lock in the new name.

  Step 7 — Double-click into your newly renamed folder. You'll see the
  same seven subfolders already sitting there, empty and ready. There
  is nothing to delete or clean out — just start saving April's real
  documents directly into the matching subfolders.

TROUBLESHOOTING
----------------
"A window popped up saying the publisher could not be verified"

This is expected, and nothing is wrong. The full warning looks like
this:

    "The publisher could not be verified. Are you sure you want to
    run this software?"
    Publisher: Unknown Publisher

Windows shows this for any script downloaded from the internet that
wasn't purchased through a paid certificate service — which is normal
for a personal tool like this one. It does not mean the file is unsafe.

What to do: click the "Run" button on that warning window, and the
script will continue normally.

"A window mentioned something about execution policy"

This is also normal and already taken care of for you inside the .bat
file. You don't need to change any settings on your computer.

---
Created and designed by S. Michelle Murray
